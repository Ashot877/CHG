# Change Helper · Personal Themes (isolated patch)

This patch is **not** a new Liana-only application. It adds a reusable visual theme engine to the existing Change Helper.

## Changed/new files
- `app.py` **replace existing**
- `core/ui.py` **replace existing**
- `core/themes.py` **add**
- `core/theme_styles.py` **add**

Leave `core/styles.py`, Jira tools, `requirements.txt` and other files unchanged.
Do not upload this readme unless you want it.

## Test in an isolated branch
1. GitHub repository > main branch dropdown > create `feature/personal-themes` from main.
2. Upload the four files into that branch, preserving their paths.
3. Streamlit Cloud > Create app > select the same repo + `feature/personal-themes` + `app.py`.
4. Configure **test** Secrets in Streamlit Cloud (never commit credentials to GitHub).
5. Use a read-only/test Jira account if possible; branch isolation does not isolate Jira data.

## Preview Liana's theme from your own login (test app only)
Add these non-secret settings to the existing `[app]` section in **test app Secrets**:

```toml
[app]
enable_theme_preview = true
theme_preview_users = ["ashot.mkrtchyan"]
```

Do not create a second `[app]` if one exists; insert only the two fields.
On login, an allowlisted tester sees `Theme preview · visual only` in the sidebar.
Choose `Blaugrana · Liana Edition`; it does not change the Jira user or permissions.
In production, omit `enable_theme_preview` (defaults to false).

## Assign a theme later
To assign an existing theme to an account without editing code, add
`theme = "aurora"` inside the corresponding `[users.some_user]` section in
Streamlit Cloud Secrets. A sample `aurora` theme is included but not assigned.
Liana gets `blaugrana` automatically via username mapping unless overridden.
Add more theme palette entries in `core/themes.py`; leave `app.py` and `core/ui.py` alone.

## Security
Previously shared Jira tokens and simple passwords should be rotated.
Test apps with production Jira write credentials can change real issues.
Never commit `.streamlit/secrets.toml` or production credentials.
Keep test deployment private and within your company data/security requirements.
